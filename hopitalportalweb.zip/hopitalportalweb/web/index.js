function tap()
{
	alert("HELLO");
}